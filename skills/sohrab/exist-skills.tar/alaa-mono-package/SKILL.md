---
name: alaa-mono-package
description: "Use this skill when the task involves changes under `packages/*` or changes to how the root app consumes an internal package. Do not use it when the task is generic CI or deployment work with no package-boundary impact."
---




# Alaa Mono Package

## Purpose

Use this skill to protect workspace package boundaries in frontend monorepos.

This skill owns:

- `packages/*` consumption rules
- dist-only package entrypoints
- peer dependency and dedupe expectations
- package CSS and asset emission into the final browser build
- verification of missing-chunk and missing-asset problems caused by package boundaries

## When to use

Use this skill when the task includes:

- changes under `packages/*`
- changes to how the root app consumes an internal package
- package build output or entrypoint changes
- package CSS, font, image, or asset emission
- missing assets or missing chunks related to internal packages

## When NOT to use

Do not use this skill when:

- the task is generic CI or deployment work with no package-boundary impact
- the task is frontend logic only inside the root app
- the repo does not use workspace packages

## Quick start

1. Read the repo-local `AGENTS.md`.
2. Read `references/00-source-map.md` when the task is version-sensitive, package-manager-sensitive, or security-sensitive.
3. Read `references/10-package-boundary-and-entrypoints.md`.
4. Load only the smallest additional reference file needed for the issue.
5. Validate with a real build output check instead of trusting config alone.

## Symptom map

| Symptom                                       | Likely cause to check first                        |
|-----------------------------------------------|----------------------------------------------------|
| peer dependency conflict                      | package boundary or peer version contract drift    |
| missing CSS in consumer app                   | asset emission or package export wiring            |
| wrong SSR asset path                          | public-path or dist contract mismatch              |
| duplicate runtime dependency                  | workspace hoisting or peer vs dependency confusion |
| package works locally but fails after publish | dist-only artifact or export-map mismatch          |

## Companion routing

- Frontend implementation policy:
  - pair with `$alaa-frontend-developer`
- Build, artifact, or deployment contract issues:
  - pair with `$alaa-frontend-devops`
- Quasar config or Vite bundling behavior:
  - pair with `$quasar-skill-packe`

## Reference navigation

- Official-first source priority, freshness triggers, and community-troubleshooting boundary:
  - `references/00-source-map.md`
- Package boundaries, entrypoints, and dist-only consumption:
  - `references/10-package-boundary-and-entrypoints.md`
- Peer dependencies, dedupe, and package build output:
  - `references/20-peer-deps-dedupe-and-build-output.md`
- CSS, asset emission, and final browser asset placement:
  - `references/30-assets-css-and-ssr-client-assets.md`
- Audit steps and validation loop:
  - `references/40-audit-and-verification.md`

## Maintenance rules

- Keep this skill about package contracts, not generic frontend logic.
- Keep examples portable across monorepos.
- Treat community package-manager notes as troubleshooting-only until official docs and local artifacts confirm them.
- Re-check bundler and package-manager guidance before changing the dependency rules in this skill.
