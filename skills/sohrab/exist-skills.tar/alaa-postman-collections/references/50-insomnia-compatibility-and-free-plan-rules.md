# Insomnia Compatibility And Free Plan Rules

## Portability baseline

Treat the primary artifact as:

- Postman Collection Format v2.1 JSON
- companion Postman environment JSON files with safe placeholders

That is the most reliable baseline for both Postman-first work and downstream Insomnia import.

## Official Insomnia import support

Current official Insomnia docs state that Insomnia can import:

- Postman collections
- Swagger or OpenAPI specs
- cURL commands
- Insomnia files
- HAR files
- WSDL files

Current official guidance also states:

- Postman collections and environments can be imported from separate JSON files or from a Postman export directory or ZIP
- Postman collection v2.0 and v2.1 scripts should work in Insomnia after import
- if a collection uses variables from a Postman global environment, the imported collection should use an Insomnia Base Environment
- mock servers from Postman are not imported
- Insomnia request collections support pre-request and after-response scripts, collection runs, and imports from Postman collections
- Insomnia does not support collection-level authentication headers in its native model; use folder-level auth or explicit request headers when portability matters

## Insomnia Postman importer detection

Use the exact Postman v2.1 export marker in collection `info.schema`:

```text
https://schema.getpostman.com/json/collection/v2.1.0/collection.json
```

Do not use `https://schema.getpostman.com/collection/json/v2.1.0/draft-04/collection.json` as the collection `info.schema`. That URL is useful for schema validation, but Insomnia's importer detection can fail before schema validation and report `No importers found for file`.

## Practical compatibility rules

- Prefer constructs that survive import with minimal interpretation.
- Favor folder-level auth when strong Insomnia clarity matters.
- Keep scripts simple and modern.
- Do not make the core workflow depend on Postman features that Insomnia will drop or reinterpret.
- Prefer self-contained scripts over Postman Package Library dependencies.
- Prefer ordinary request order and saved environment variables over complex `pm.execution.*` runner control.
- If you cannot run an Insomnia import check locally, state that exact gap in the task output.

## Postman free-plan rules that matter here

Current official Postman pricing states that the Free plan includes:

- API client and core tools
- collections and environments
- collection generation and sync
- Native Git
- Postman CLI
- unlimited Collection Runner and Performance Testing runs

Paid plans add features such as custom-branded documentation, custom domains, broader collaboration, and enterprise governance. Therefore:

- do not require paid Postman documentation branding
- do not require custom domains
- do not require team-only governance or private workspace features
- keep the workflow local and file-based by default

## Insomnia free-plan rules that matter here

Current official Insomnia pricing states that the free Essentials tier includes:

- unlimited Cloud and Local projects
- unlimited collection runs
- unlimited environments
- Inso CLI access
- plugin access

Therefore:

- do not assume a paid Insomnia plan is needed to import or run the artifact
- keep validation steps compatible with free local usage
- treat enterprise-only storage controls, RBAC, SSO, and vault integrations as out of scope

## Cloud-only and paid-only features to keep optional

- Postman monitors
- Postman cloud publishing workflows
- custom-branded documentation
- custom domains
- enterprise governance or vault integrations
- Insomnia enterprise storage controls or SSO
