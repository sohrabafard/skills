---
name: alaa-services-contract
description: "Hard contract for Ala services such as auth, content, comment, ticket, gateway, entitlement-platform, wa, notification, assessment, and future services. Use when enforcing exact Ala behavior for `/api/health`, `/api/ready`, service naming, response envelopes, RequestObservabilityMiddleware, ResolveUserMiddleware, trusted headers, public `project_id` UUIDv7 handling, `X-Project-Id` trusted context, `X-Request-Id`, `traceparent`, queryable `trace_id`, event/code naming, Laravel Resource-first `/api/*` responses, frontend-to-gateway-to-backend flow, the Alaa Platform Observability Directive, OpenTelemetry, OTLP, Collector, SigNoz, Sentry fallback, Prometheus rules, Arvan Kubernetes, Docker Compose/Swarm, shared Postgres mode, shared infra reuse, canonical DNS aliases, auth key ownership, registry usage, fast-test SQLite support, or the shared `service-ci-kit` GitLab CI/CD baseline. Use when cross-service consistency matters more than local preference."
---

# Alaa Services Contract

Use this skill as the hard contract layer for Ala backend services.

This skill is intentionally Ala-specific. It exists to keep Ala services aligned with one exact contract so agent output stays consistent across repositories. Treat the contract here as normative. When a target repository deviates, converge it to this contract or explicitly report the blocker. Do not improvise alternate envelopes, headers, event names, route names, middleware semantics, or repo-local observability contracts.

Keep this top-level file small. Read the reference files for the exact contract and apply steps.

This skill explains how a normal Ala backend fits into the larger platform:
- frontend calls the gateway
- gateway owns authentication, spoofed-header removal, and trusted-header injection
- the gateway may call a request-time authorization runtime such as `authz-sidecar` or `entitlement-spoa`
- entitlement-platform keeps normalized authorization truth in `entitlement-api`, projects derived tuples through `projector`, and serves route-time checks from OpenFGA
- the backend still owns normalized request handling, business authorization, response contracts, and observability inside the service boundary

## Quick start

1. Read the repo-local `AGENTS.md`.
2. Read `references/00-topic-map.md`.
3. Select the repository role first: frontend-facing backend behind gateway, internal backend, auth-boundary service, or authz-runtime or control-plane service.
4. Then select the service mode: any Ala backend, deployment and runtime contract, Laravel backend, Laravel downstream trusted service, or the platform observability directive.
5. Read the smallest relevant reference file first.
6. Read `references/21-alaa-platform-observability-directive.md` whenever the task includes telemetry design, OpenTelemetry, OTLP logs/traces, Prometheus, metric catalogs, exception delivery, SigNoz, Sentry, queue or DB instrumentation, collector topology, or cross-runtime observability alignment between Go, Laravel, HAProxy, Vector, and OpenFGA.
7. Read `references/full-guide.md` when the task is cross-cutting, high-risk, or you need the preserved whole-contract view in one file.
8. Load the required companion skills before implementation work outside this skill's ownership.
9. Load `$alaa-crockford-base32-codecs` when the task needs shared Crockford Base32 or UUIDv7 helper assets across runtimes.
10. For any Laravel request body, query parameter, or DTO field named `project_id`, read `references/30-trusted-ingress-and-laravel-contract.md` before editing validation or resolution code.

## When NOT to use

- Do not use for purely local feature work that does not affect shared Ala service contracts.
- Do not use for frontend UI design unless gateway, API, trust-boundary, or observability contracts are involved.
- Do not use to override a repository-specific blocker; report the incompatibility instead.

## Hard contract rule

- Enforce the exact contract defined by this skill for Ala services.
- Do not downgrade exact outputs into optional recommendations.
- Do not invent local variants when this skill already defines the contract.
- Do not treat logs, traces, metrics, or exception evidence as optional for long-lived Ala services.
- When this skill replaces a legacy header, field, event, or helper, remove the old implementation instead of keeping stale compatibility code in the service.
- If a repository cannot adopt a rule exactly, stop and report the incompatibility.
- Keep references relative to this skill folder so the skill remains usable on different machines.
- Ala service names such as `auth`, `content`, `comment`, `ticket`, `vod`, and `wa` are valid inside this skill because it is intentionally platform-specific.

## Companion routing

Load these companion skills when their concern is in scope:
- `$alaa-trust-gateway-auth`
  - Load when trusted headers, auth error semantics, compact claim semantics, or tenant or project propagation are involved.
- `$alaa-observability-soc`
  - Load when logs, traces, metrics, alerting, incident evidence requirements, or security-log catalog work are in scope.
- `$alaa-golang`
  - Load when a Go service must implement this contract with Chi, OTLP, Prometheus, or service-runtime patterns that are already standardized in Ala.
- `$alaa-docker-production`
  - Load when the task changes Dockerfiles, Compose or Swarm wrappers, registry plumbing, secret mounting, runtime users, or container hardening.
- `$caas-arvan-kuber`
  - Load when the task changes the Arvan Kubernetes production path, Helm values, OCI charts, or GitLab delivery wiring.
- `$alaa-gitlab-ci-cd`
  - Load when `.gitlab-ci.yml`, GitLab validation, kit ref bumps, or pipeline debugging are in scope for an Ala service that should follow the shared `service-ci-kit` baseline.
- `$alaa-laravel-architecture`
  - Load when Laravel middleware, controllers, resources, DTOs, or service boundaries change.
- `$alaa-php-clean-code`
  - Load before implementing or refactoring PHP or Laravel code.
- `$alaa-data-layer`
  - Load when readiness checks depend on PostgreSQL, Redis, ClickHouse, bootstrap data, or persistence invariants.
- `$alaa-async-messaging` and `$alaa-laravel-job-rabbitmq`
  - Load when readiness or runtime behavior depends on RabbitMQ, queues, or workers.
- `$alaa-docs-farsi`
  - Load when docs, Postman artifacts, or runbooks change.

## Auth-specific routing

- When the task touches the `auth` service and any frontend or frontend-facing identity integration depends on academic form behavior, read `docs/ops/auth-academic-policy-contract.md` in the `auth` repository before planning or editing.
- Treat that document as the canonical frontend integration contract for auth academic policy.
- When auth academic policy changes, update the frontend implementation and any contract-facing docs or Postman artifacts in the same effort.

## Reference navigation

- skill scope, use cases, service-mode selection, and auth-specific routing:
  - `references/05-scope-service-modes-and-auth-routing.md`
- topic routing and service-mode selection:
  - `references/00-topic-map.md`
- core service modes, Ala service map, service identity, route families, and exact readiness envelope:
  - `references/10-core-service-contract.md`
- deploy modes, Arvan-versus-Docker ownership, shared `service-ci-kit` GitLab CI/CD baseline, shared-versus-external Postgres rules, hard shared-infra reuse, DNS and VIP naming, key ownership, registry contract, and SQLite test support:
  - `references/15-deployment-and-runtime-contract.md`
- exact observability headers, `traceparent`, request logs, event names, and `RequestObservabilityMiddleware`:
  - `references/20-operational-and-observability-contract.md`
- full telemetry architecture, OpenTelemetry collector gateway rules, Prometheus scrape rules, shared metric catalog, and cross-runtime observability guidance:
  - `references/21-alaa-platform-observability-directive.md`
- end-to-end platform flow, frontend or gateway orientation, service ownership, and internal-hop boundaries:
  - `references/25-end-to-end-flow-and-boundaries.md`
- exact trusted-ingress rules, Laravel response boundaries, `ResolveUserMiddleware`, and how backend business auth fits after gateway allow:
  - `references/30-trusted-ingress-and-laravel-contract.md`
- canonical public `project_id` UUIDv7 handling, `TrustedProjectContext` helper naming, and copy-oriented Laravel validation baselines:
  - `references/30-trusted-ingress-and-laravel-contract.md`
  - `references/50-laravel-copy-baselines.md`
- apply checklist, review checklist, and anti-patterns:
  - `references/40-apply-checklist-and-anti-patterns.md`
- copy-oriented Laravel class and helper baselines:
  - `references/50-laravel-copy-baselines.md`
- official-first source map and freshness triggers:
  - `references/90-source-map.md`
- complete preserved contract in one file:
  - `references/full-guide.md`

## Maintenance rules

- Keep this file routing-first and explicit.
- Keep exact contract details in `references/`.
- Use relative reference paths only.
- When a normative rule changes in a split reference file, update `references/full-guide.md` in the same patch so the preserved whole-guide view stays complete.
- Do not strand normative Ala rules in only one document. Keep `references/00-topic-map.md`, the split references, and `references/full-guide.md` aligned.
- Keep exact route names, header names, event names, code families, metric names, and observability field names stable unless the contract is intentionally revised.
- Keep the Ala deploy contract aligned with `alaa-docker-production` and `caas-arvan-kuber` when ownership boundaries change.
- When this skill changes a contract owned jointly with another skill, update that companion skill in the same effort so the pack remains consistent.
