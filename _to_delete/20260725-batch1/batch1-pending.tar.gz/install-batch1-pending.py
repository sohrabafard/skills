#!/usr/bin/env python3
"""Install the two pending Batch 1 skills into the skills repository.

Truncates each target in place instead of unlinking, because the device mount
forbids unlink. Run from anywhere:

    python3 install-batch1-pending.py /path/to/skills-repo

Expects this script to sit beside the payload directories it installs.
"""
import shutil
import sys
from pathlib import Path

PAYLOADS = ("alaa-controlled-ops", "service-runtime-kit-governance")
RETIRE = {"alaa-controlled-ops": ["references/00-topic-map.md"]}


def write_in_place(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    data = src.read_bytes()
    existed = dst.exists()
    with open(dst, "wb") as fh:          # truncates, never unlinks
        fh.write(data)
    return f"{'updated' if existed else 'created'} {len(data):>7d}  {dst}"


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    repo = Path(sys.argv[1]).resolve()
    sohrab = repo / "skills" / "sohrab"
    if not sohrab.is_dir():
        print(f"error: {sohrab} is not a directory — pass the repository root")
        return 1
    here = Path(__file__).resolve().parent
    trash = repo / "_to_delete" / "20260725-batch1"
    trash.mkdir(parents=True, exist_ok=True)

    for name in PAYLOADS:
        src_root = here / name
        if not src_root.is_dir():
            print(f"skip {name}: payload missing at {src_root}")
            continue
        for src in sorted(p for p in src_root.rglob("*") if p.is_file()):
            print(" ", write_in_place(src, sohrab / name / src.relative_to(src_root)))
        for rel in RETIRE.get(name, []):
            victim = sohrab / name / rel
            if victim.exists():
                dest = trash / f"{name}--{rel.replace('/', '--')}"
                shutil.move(str(victim), str(dest))
                print(f"  retired          {victim}  ->  {dest}")

    readme = here / "README.fa.md"
    if readme.is_file():
        print(" ", write_in_place(readme, sohrab / "README.fa.md"))
    print("\ndone. run `git status --short` to review.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
