# Ansible ruleset: Structure And Naming

## 1. Structure

**1.1 A project has one inventory directory per environment.** Production and
staging inventories are separate trees under `inventory/`, each with its own
`hosts`, `group_vars/` and `host_vars/`. Sharing one inventory between
environments and switching on a variable means a mistyped `--limit` reaches
production.
*Reported by:* nothing. This is a review finding.

**1.2 A role has `tasks/main.yml`.** `defaults/`, `handlers/`, `meta/`,
`templates/` and `vars/` are present when the role uses them, and each present
directory has a `main.yml`.
*Reported by:* `scripts/validate_role.sh` stage 1.

**1.3 A role declares `meta/argument_specs.yml`.** Every variable the role reads
from outside itself appears there with a type, and with `required: true` or a
default. This is validation at the boundary: without it, a missing variable
surfaces as a Jinja error in the middle of a run rather than as a refusal at the
start.
*Reported by:* `ansible-lint` rule `role-argument-spec`.

**1.4 `meta/main.yml` states `min_ansible_version` and the platform list it was
tested on.** A platform not in the list is a platform nobody tested.
*Reported by:* `ansible-lint` rules `meta-incorrect`, `meta-runtime`.

## 2. Naming

**2.1 Every task has a `name`.** The name is what an operator reads in the
output of a failing run at 03:00.
*Reported by:* `ansible-lint` rule `name[missing]`, which `assets/.ansible-lint`
enables. `scripts/check_assets.sh` asserts that it fires.

**2.2 A task name starts with a capital letter and a verb in the imperative:**
"Install nginx", "Ensure the configuration directory exists", "Reload the web
server". A name that describes a noun ("Nginx configuration") does not say what
the task did when it appears beside `changed`.
*Reported by:* `ansible-lint` rule `name[casing]` for the capital;
nothing reports the verb.

**2.3 Variables are `snake_case`,** and a role's variables carry the role name
as a prefix: `nginx_worker_processes`, not `workers`. An unprefixed variable in
a role collides with the same name in another role at play scope, and the
collision is silent.
*Reported by:* `ansible-lint` rule `var-naming`, with the pattern in
`assets/.ansible-lint`.

**2.4 Files and directories are lowercase with underscores.**
*Reported by:* nothing. This is a review finding.

