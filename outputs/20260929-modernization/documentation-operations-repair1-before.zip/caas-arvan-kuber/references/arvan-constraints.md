# Arvan CaaS constraints

This reference set is the single normative statement of every Arvan platform constraint. Each rule appears here once and nowhere else in this skill. Where a rule is generic Kubernetes rather than Arvan, this file names the owner instead of restating it.

Each rule carries its status: **confirmed by Arvan** with the page that says so, **observed** with what was seen and when, or **unverified**. Treat an unverified rule as a hypothesis to test with discovery, not as a constraint to enforce.

Step 1 in `SKILL.md` establishes observable capabilities and permissions separately from server version; unknown discovery remains unknown. Read `references/arvan-capability-matrix.md` for the per-kind answer.

## 1. Resources are mandatory and parity is enforced

Read this topic in [10-resource-parity.md](arvan-constraints/10-resource-parity.md).

### CPU written as decimal cores, and why this is style rather than a constraint

Read the detailed explanation in [10-resource-parity.md](arvan-constraints/10-resource-parity.md#cpu-written-as-decimal-cores-and-why-this-is-style-rather-than-a-constraint).

## 2. Scaling is stateless-only

Read this topic in [20-stateful-storage.md](arvan-constraints/20-stateful-storage.md).

## 3. Disk lifecycle

Read this topic in [20-stateful-storage.md](arvan-constraints/20-stateful-storage.md).

## 4. Exposure has three modes, and one uses annotations Arvan does not document

Read this topic in [30-exposure-config-and-secrets.md](arvan-constraints/30-exposure-config-and-secrets.md).

## 5. Namespace scope

Read this topic in [40-namespace-and-panel-scope.md](arvan-constraints/40-namespace-and-panel-scope.md).

## 6. Panel behaviour

Read this topic in [40-namespace-and-panel-scope.md](arvan-constraints/40-namespace-and-panel-scope.md).

## 7. Config mount safety

Read this topic in [30-exposure-config-and-secrets.md](arvan-constraints/30-exposure-config-and-secrets.md).

## 8. Node affinity for CPU generation

Read this topic in [50-node-placement-and-portability.md](arvan-constraints/50-node-placement-and-portability.md).

## 9. Portability toggles

Read this topic in [50-node-placement-and-portability.md](arvan-constraints/50-node-placement-and-portability.md).

## 10. Secrets

Read this topic in [30-exposure-config-and-secrets.md](arvan-constraints/30-exposure-config-and-secrets.md).

## 11. Failure map for delivery on Arvan

Read this topic in [60-delivery-failure-map.md](arvan-constraints/60-delivery-failure-map.md).
