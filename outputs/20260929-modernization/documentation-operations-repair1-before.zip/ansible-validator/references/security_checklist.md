# Security predicates, and the command that evaluates each one

This file is the pair's single statement of the Ansible security predicates and
of Ansible Vault mechanics. `ansible-generator` (`/ansible-generator`) keeps only the authoring-time shape rules — where `no_log`
goes, what `mode` to write — and cites this file by line for everything else.

A checklist item with no command that evaluates it is a preference. Every
predicate below names its command.

**Whose decision a finding is.** This skill reports. It does not decide whether
a finding blocks a change. `/alaa-security-review`
owns fail-closed doctrine for security decisions and `/alaa-reliability-sla` owns fail-open and degradation for availability. The
discriminating question, which you may quote: *when this dependency cannot
answer, does proceeding without it let something through that must not get
through?* A secret-scan finding answers yes, so it is fail-closed by default.

**A scan that could not run is a blocked audit, not a clean one.** Every script
here exits 2 when it could not run, and 2 is never a pass.

---

## The three commands that make up an audit

Read this section in [10-audit-commands.md](security_checklist/10-audit-commands.md).

## S1. No credential is a literal in a tracked file

Read this section in [20-credential-storage.md](security_checklist/20-credential-storage.md).

## S2. `no_log` covers every task that can print a secret

Read this section in [30-secret-redaction.md](security_checklist/30-secret-redaction.md).

## S3. Vault mechanics

Read this section in [40-vault-mechanics.md](security_checklist/40-vault-mechanics.md).

## S4. Privilege escalation is scoped

Read this section in [50-privilege-escalation.md](security_checklist/50-privilege-escalation.md).

## S5. Every written path has an explicit mode, and none is world-writable

Read this section in [60-file-permissions.md](security_checklist/60-file-permissions.md).

## S6. No unvalidated value reaches a shell

Read this section in [70-shell-inputs.md](security_checklist/70-shell-inputs.md).

## S7. Transport is encrypted and verified

Read this section in [80-transport-verification.md](security_checklist/80-transport-verification.md).

## S8. Host keys are checked

Read this section in [90-host-key-verification.md](security_checklist/90-host-key-verification.md).

## S9. A service binds to an address, not to everything

Read this section in [100-service-binding.md](security_checklist/100-service-binding.md).

## S10. SELinux and AppArmor stay enforcing

Read this section in [110-mandatory-access-control.md](security_checklist/110-mandatory-access-control.md).

## S11. A security-relevant change is visible after the fact

Read this section in [120-audit-trail.md](security_checklist/120-audit-trail.md).

## S12. The tools that are not this skill's

Read this section in [130-tool-boundaries.md](security_checklist/130-tool-boundaries.md).
