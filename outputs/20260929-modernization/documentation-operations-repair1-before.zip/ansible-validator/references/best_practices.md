# The Ansible ruleset

These references are the pair's single statement of the rules an Ansible artifact is
measured against. `ansible-generator` (`/ansible-generator`) generates against these rules and does not restate them;
its `references/best-practices.md` holds only the rules that apply at authoring
time and have no checker, and routes here for everything else.

The ownership rule that produced that split: **a rule lives with the skill that
ships the checker which reports its violation.** Only this skill ships
checkers, so the ruleset lives here. Every rule below names the checker that
reports it, or says plainly that nothing reports it yet.

Read this file when a finding needs a remediation citation, and cite the rule
number in the report.

---

## 1. Structure

Read this section in [10-structure-and-naming.md](best_practices/10-structure-and-naming.md).

## 2. Naming

Read this section in [10-structure-and-naming.md](best_practices/10-structure-and-naming.md).

## 3. Module selection

Read this section in [20-module-selection.md](best_practices/20-module-selection.md).

## 4. Idempotency

Read this section in [30-idempotency.md](best_practices/30-idempotency.md).

## 5. Error handling

Read this section in [40-error-handling.md](best_practices/40-error-handling.md).

## 6. Variables

Read this section in [50-variable-precedence.md](best_practices/50-variable-precedence.md).

## 7. Conditionals and loops

Read this section in [60-conditionals-and-loops.md](best_practices/60-conditionals-and-loops.md).

## 8. Security rules that apply at authoring time

Read this section in [70-authoring-security.md](best_practices/70-authoring-security.md).

## 9. Performance

Read this section in [80-performance.md](best_practices/80-performance.md).

## 10. Check mode

Read this section in [90-check-mode-and-documentation.md](best_practices/90-check-mode-and-documentation.md).

## 11. Documentation

Read this section in [90-check-mode-and-documentation.md](best_practices/90-check-mode-and-documentation.md).
