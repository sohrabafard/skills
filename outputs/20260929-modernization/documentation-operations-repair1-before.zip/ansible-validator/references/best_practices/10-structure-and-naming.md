# Ansible ruleset: Structure and Naming

## 1. Structure

Read this section in [01-project-structure.md](01-project-structure.md).

## 2. Naming

Read this section in [02-task-and-variable-naming.md](02-task-and-variable-naming.md).
