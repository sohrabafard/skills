# Retries and job creation

Use the narrow procedure for the task.

## `retry:` and its failure classes

See [Retry failure classes](./50-retry-failure-classes.md).

## Skipping inside a script versus not creating the job

See [Job creation conditions](./60-job-creation-conditions.md).

