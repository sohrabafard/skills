# Topic Map

The router for this skill. Every reference below is unread until its condition fires, and that is the point: the body of a skill is paid for on every run, while a reference is paid for only when something makes it necessary. Match your situation to a row, read that file, and do not pre-load the rest.

Rows are conditions, not headings. If your situation is not listed, no reference here owns it — say so rather than reading the nearest-looking file.

| You are about to | Read | Because |
|---|---|---|
| Decide how a generated prompt will actually activate a skill, write a call site, place a trigger, choose between a trigger-led and a goal-led message, or write a completion condition | `references/06-invocation-and-composition.md` | Syntax alone does not activate a skill; placement, role consistency, and reachability do |
| Write delegation language and need to know whether to cap fan-out or authorize it | `references/06-invocation-and-composition.md` | It owns delegation polarity, and the wrong direction fails silently on either family |
| Tune GPT prompts or choose active Codex profiles | `references/12-gpt-6.md` | Separates model capability, runtime availability, and local policy |
| Evaluate a recorded legacy exception or compare historical GPT behavior | `references/10-gpt-5-6.md` | Legacy guidance is not the active routing default |
| Design or execute representative Codex model/effort comparisons | `references/92-agent-evaluation.md` | Defines controlled comparisons and honest evidence status |
| Design Claude comparisons, record identity or fallback, or validate calibration evidence | `references/93-claude-evaluation.md` | Source checks and synthetic fixtures do not prove runtime behavior |
| Use Codex's goal loop, subagents, batch jobs, `AGENTS.md` discovery, or its slash commands | `references/11-codex-runtime-features.md` | These are harness features with version gates and hard limits a prompt must respect |
| Tune current Opus prompting or migrate older Opus instructions | `references/21-opus-5-5.md` | Calibration and API boundaries differ from historical Opus 5 |
| Compare historical Opus 5 behavior explicitly | `references/20-opus-5.md` | Retained evidence does not authorize current pins |
| Tune current Sonnet prompting or migrate Sonnet API controls | `references/31-sonnet-5-5.md` | Recalibrated effort, thinking modes and tool contracts differ from Sonnet 5 |
| Compare historical Sonnet 5 behavior explicitly | `references/30-sonnet-5.md` | Retained evidence does not authorize current pins |
| Tune current Fable prompting or assess an explicit comparison | `references/42-fable-5-1.md` | Its verification and API guidance differ from older Fable |
| Compare historical Fable 5 behavior explicitly | `references/40-fable-5.md` | Older verification reminders are historical, not current instructions |
| Assess Haiku for a bounded comparison | `references/35-haiku-4-5.md` | It lacks effort support and uses a different thinking control |
| Use Claude Code's `/loop`, subagents, workflows, plan mode, or `/goal` | `references/41-claude-code-runtime-features.md` | Concurrency caps, nesting defaults, and evaluator scope decide whether a prompt can work |
| Set or change an effort level, or judge whether a lane needs a higher tier | `references/50-effort-and-thinking.md` | Model and effort are separate decisions, and an effort inherited from another generation is an untested assumption |
| Decide whether what you are about to write is a prompt, an instruction file, a skill, or a subagent | `references/60-skill-authoring.md` | It holds the four-way test, and choosing wrong is the most common authoring defect |
| Write, review, or repair a skill | `references/60-skill-authoring.md` | It owns the authoring procedure and how to split a subject into references |
| Shorten or edit an artifact that controls another agent, or judge whether a change altered behavior | `references/60-skill-authoring.md` | It owns equivalence and compression; read it with the artifact's own reference, which owns that artifact's required structure and content |
| Look up a skill discovery path, a frontmatter key surface, or a description character budget | `references/61-skill-platform-mechanics.md` | These are per-runtime lookups that go stale and must not be recalled from memory |
| Write, trim, or split an `AGENTS.md` or `CLAUDE.md` | `references/70-agent-instruction-files.md` | An instruction file is loaded unconditionally, so its economics differ from every other artifact here; trimming one also needs the row above |
| Define a subagent, pin its model, effort, and tools, or write its dispatch text | `references/80-subagent-authoring.md` | It owns authority boundaries, output contracts, and the test separating a redundant self-check from a real gate; shortening a definition or a dispatch also needs the compression row |
| Choose a model, or compare models across runtimes | `references/90-model-selection.md` | Structured policy owns role pins; current references explain selection limits |
| Ground a version-sensitive claim, or judge whether a number must be re-fetched before it is quoted | `references/00-source-map.md` | It owns source priority and the freshness triggers that decide when recall is not allowed |
